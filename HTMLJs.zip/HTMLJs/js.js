function calculateFees() {
    const studentType = document.getElementById("studentType").value;
    const residency = document.getElementById("residency").value;
    const credits = parseFloat(document.getElementById("credits").value);

    let registrationFee, tuitionRate;

    if (studentType === "bachelor") {
        registrationFee = (residency === "in-state") ? 200 : 600;
        tuitionRate = (residency === "in-state") ? 350 : 700;
    } else if (studentType === "master") {
        registrationFee = (residency === "in-state") ? 300 : 900;
        tuitionRate = (residency === "in-state") ? 450 : 900;
    }

    const tuition = tuitionRate * credits;
    const totalFee = registrationFee + tuition;

    document.getElementById("registrationFee").textContent = registrationFee;
    document.getElementById("tuitionRate").textContent = tuitionRate;
    document.getElementById("tuition").textContent = tuition;
    document.getElementById("totalFee").textContent = totalFee;

    document.getElementById("result").style.display = "block";
}

function clearForm() {
    // Reload the page
    location.reload();
}
